export const getLocale = (state) => state.locale.lang;
