/** TodoMVC model definitions **/

export class User {
    password;
    email;
}