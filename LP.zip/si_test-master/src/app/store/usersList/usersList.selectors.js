export const getRegisteredUsers = (state) => state.usersList;
