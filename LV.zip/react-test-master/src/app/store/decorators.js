export const decoreAction = (action) => {
  action.type = action().type
  return action
}