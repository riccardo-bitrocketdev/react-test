import styled from 'styled-components'

export default styled.div`
  padding: 0 2em;
`