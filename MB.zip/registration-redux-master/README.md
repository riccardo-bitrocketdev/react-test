This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Technologies
* ReactJS
* Redux-saga
* React-router
* Styled-components
* Storybook
