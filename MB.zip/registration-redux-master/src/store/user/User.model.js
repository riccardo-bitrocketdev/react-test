export default class UserModel {
    email;
    password;
    }