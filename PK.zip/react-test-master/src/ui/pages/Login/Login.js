import React, { Component } from 'react';
import { Wrapper } from "../../elements/Wrapper";
import LoginForm from '../../components/LoginForm/LoginForm';
import { PageHeader } from '../../elements/PageHeader';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

class Login extends Component {
    render() {
        const { forLoginPage, error, isLoggedIn, intl } = this.props;
        const headerText = forLoginPage ? intl.formatMessage({ id: 'login.welcome' }) : intl.formatMessage({ id: 'register.welcome' });
        if (isLoggedIn) {
            return (
                <Redirect to="/home"/>
            )
        } else {
            return (
                <Wrapper flexDirection="column" justifyContent="center" flexGrow="1" margin="-10% 0 0 0">
                    <Wrapper justifyContent="center">
                        <PageHeader>{headerText}</PageHeader>
                    </Wrapper>
                    <Wrapper flexDirection="column" alignItems="center" justifyContent="center">
                        <LoginForm forLoginPage={forLoginPage} error={error} />
                        <Link to={forLoginPage ? '/register' : '/login'}>{
                            forLoginPage ?
                                intl.formatMessage({ id: 'register.anchorText' }) :
                                intl.formatMessage({ id: 'login.anchorText' })
                        }</Link>
                    </Wrapper>
                </Wrapper>
            );
        }
    }
}

const mapStateToProps = state => {
    return {
        isLoggedIn: state.users.authenticated,
        error: state.users.errorMessage
    }
};

export default connect(
    mapStateToProps
)(injectIntl(Login))

Login.propTypes = {
    forLoginPage: PropTypes.bool.isRequired,
    error: PropTypes.string.isRequired
};
